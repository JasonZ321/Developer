//
//  PostFixAppDelegate.h
//  PostFix
//
//  Created by Jason Zhou on 13-8-27.
//  Copyright (c) 2013年 Jiasheng Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PostFixAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
